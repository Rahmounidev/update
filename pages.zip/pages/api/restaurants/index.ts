import { NextApiRequest, NextApiResponse } from "next";
import { prisma } from "@/lib/prisma";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    // Récupérer les paramètres de la requête
    const { cuisine, isOpen, minRating } = req.query;

    // Initialisation des filtres de base
    const filters: any = {
      role: "RESTAURANT",
      isActive: true,  // Filtrer les restaurants actifs
    };

    // Ajouter le filtre pour les restaurants ouverts
    if (isOpen === "true") {
      filters.isOpen = true;
    }

    // Ajouter le filtre pour la cuisine si fourni
    if (cuisine) {
      filters.cuisines = {
        some: {
          name: {
            equals: String(cuisine),  // Assurer que cuisine est une chaîne de caractères
            mode: "insensitive",  // Ignorer la casse lors de la recherche
          },
        },
      };
    }

    // Ajouter le filtre pour les évaluations minimales si fourni
    if (minRating) {
      filters.reviews = {
        some: {
          rating: {
            gte: parseFloat(minRating as string),  // Convertir minRating en nombre
          },
        },
      };
    }

    // Recherche des restaurants selon les filtres
    const restaurants = await prisma.users.findMany({
      where: filters,
      select: {
        id: true,
        restaurantName: true,
        name: true,
        description: true,
        logo: true,
        city: true,
        address: true,
        phone: true,
        hours: true,
        isOpen: true,
        minimumOrder: true,
        deliveryRadius: true,
        customMessage: true,
        cuisines: {
          select: {
            name: true,
          },
        },
        promotions: {
          where: {
            isActive: true,
          },
          select: {
            name: true,  // ✅ Champ correct dans le modèle "promotions"
          },
        },
        reviews: {
          select: {
            rating: true,
          },
        },
        dishes: {
          where: {
            isAvailable: true,  // S'assurer que les plats sont disponibles
          },
          select: {
            id: true,
            name: true,
            price: true,
            image: true,
          },
          take: 3,  // Limiter à 3 plats
        },
      },
    });

    // Réponse avec la liste des restaurants
    res.status(200).json({ restaurants });
  } catch (error) {
    console.error("Restaurants error:", error);
    // Gérer les erreurs
    res.status(500).json({
      message: "Erreur lors de la récupération des restaurants",
    });
  }
}
